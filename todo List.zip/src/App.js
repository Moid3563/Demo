import logo from './logo.svg';
import './App.css';
import Functional from './Functional';
import Classclick from './Classclick';
import Bind from './Bind';
import NameList from './components/NameList';
import Stylesheet from './components/Stylesheet';
import Inline from './components/Inline';
import Form from './components/Form';
import LifecycleA from './components/LifecycleA';
import FragmentDemo from './FragmentDemo';
import Table from './components/Table';
import Count from './components/Count';
import Api from './components/Api';
import RefDemo from './components/RefDemo';
import FetchNews from './components/FetchNews';
import FakeApi from './components/FakeApi';
import CRUD from './components/CRUD';
import TodoList from './TodoList';




function App() {
  return (
    <>
   {/* <Functional/>
   <Classclick/> */}
   {/* <Bind/> */}
   {/* <NameList/> */}
     {/* <Stylesheet primary={true}/> */}
     {/* <Inline/> */}
     {/* <Form/> */}
     {/* <LifecycleA/> */}
     {/* <FragmentDemo/> */}
     {/* <Table/> */}
     {/* <Count/> */}
     {/* <Api/> */}
     {/* <RefDemo/> */}
      {/* <FetchNews/>  */}
     {/* <FakeApi/> */}
     {/* <CRUD/> */}
     <TodoList/>
    </>
  );
}

export default App;
