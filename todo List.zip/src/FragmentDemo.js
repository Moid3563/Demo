import React from 'react'

function FragmentDemo() {
  return (
    <React.Fragment>
     <h1>
        FragmentDemo
    </h1>
    <p>This describe Fragment demo</p>
    </React.Fragment>
   
  )
}

export default FragmentDemo