import React from 'react'

function Column() {
  return (
    <React.Fragment>
        <td>Name</td>
        <td>Moid</td>
    </React.Fragment>
  )
}

export default Column