// import React, { Component } from 'react'

//  class Bind extends Component {

//     constructor(props) {
//       super(props)
    
//       this.state = {
//          message:"Hello"
//       }
//     //   this.clickBind = this.clickBind.bind(this)
    

//     // clickBind(){
//     //     this.setState({
//     //         message:"Goodbye!"
//     //     })
//     //     console.log(this)
        
//     clickBind=()=>{
//         this.setState({
//             message:"goodbye"
//         })
//     }
// }
//     }
//   render() { 

//     return (
     
//          <div>
//          <div>{this.state.message}</div>
//          {/* <button onClick={this.clickBind.bind(this)}>Click</button>   */}
//         {/* <button onClick={() => this.clickBind()}>Click</button>      */}
//          <button onClick= {this.clickBind}>Click</button>                                                                                                                                                                                                this.clickBind()} */}
      
//          </div>
       
     
//     )
//   }


// export default Bind